python3 -m zelz
